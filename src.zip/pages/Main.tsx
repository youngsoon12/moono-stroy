const Main = (props: any) => {
  return <div>메인페이지 입니다.</div>;
};

export default Main; 
